package com.ism.core.config.router;

public interface IRouter {
    public void navigate();
}
