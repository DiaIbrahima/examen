package com.ism.core.config.security;

import com.ism.data.entities.User;

public interface IConnexion {
    User connexion();
}
