package com.ism.views;

import com.ism.data.entities.Paiement;

public interface IPaiementView extends IView<Paiement> {
    
}
