package com.ism.data.repository;

import com.ism.core.repository.IRepository;
import com.ism.data.entities.DemandeArticle;

public interface IDemandeArticleRepository extends IRepository<DemandeArticle> {
    
}
