package com.ism.data.repository;

import com.ism.core.repository.IRepository;
import com.ism.data.entities.Detail;

public interface IDetailRepository extends IRepository<Detail> {
    
}
