package com.ism.data.enums;

public enum EtatDette {
    ENCOURS, SOLDE
}
