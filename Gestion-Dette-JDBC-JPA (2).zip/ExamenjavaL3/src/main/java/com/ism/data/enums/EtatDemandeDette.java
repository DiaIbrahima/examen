package com.ism.data.enums;

public enum EtatDemandeDette {
    ENCOURS, ANNULE, VALIDE
}
