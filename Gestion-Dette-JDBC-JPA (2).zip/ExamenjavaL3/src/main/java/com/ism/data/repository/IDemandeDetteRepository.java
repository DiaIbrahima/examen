package com.ism.data.repository;

import com.ism.core.repository.IRepository;
import com.ism.data.entities.DemandeDette;

public interface IDemandeDetteRepository extends IRepository<DemandeDette> {
}
